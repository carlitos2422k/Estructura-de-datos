#include "JuegoLetras.h"

int main() {
    // Crear una instancia del juego con ancho 10 y alto 15
    JuegoLetras juego(10, 15);
    
    // Ejecutar el juego
    juego.ejecutar();
    
    return 0;
}